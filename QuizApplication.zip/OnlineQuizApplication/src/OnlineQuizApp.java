import java.sql.*;
import java.util.*;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OnlineQuizApp {

    // JDBC Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/quizz";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";

    // Main method
    public static void main(String[] args) {
        OnlineQuizApp app = new OnlineQuizApp();
        app.run();
    }

    // Method to run the quiz application
    public void run() {
        Scanner scanner = new Scanner(System.in);
        ExecutorService executorService = Executors.newFixedThreadPool(3); // Limit to 3 concurrent users
        
        try {
            while (true) {
                System.out.println("\nWelcome to the Online Quiz Application!");
                System.out.println("1. Start Quiz");
                System.out.println("2. View Results");
                System.out.println("3. Exit");
                System.out.print("Select an option: ");
                int option = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                
                switch (option) {
                    case 1:
                        System.out.print("Enter Participant Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Participant Email: ");
                        String email = scanner.nextLine();

                        Participant participant = new Participant(name, email);
                        registerParticipant(participant);

                        Quiz quiz = createSampleQuiz();
                        executorService.submit(() -> {
                            try {
                                takeQuiz(participant, quiz);
                                viewScore(participant);
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                        });
                        break;

                    case 2:
                        System.out.println("Viewing results...");
                        // Implement viewing results logic here
                        break;

                    case 3:
                        System.out.println("Exiting...");
                        executorService.shutdown();
                        return;

                    default:
                        System.out.println("Invalid option.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Interface for quiz operations
    interface QuizOperations {
        void takeQuiz(Participant participant, Quiz quiz) throws SQLException;
        void viewScore(Participant participant) throws SQLException;
    }

    // Participant class
    private static class Participant {
        private String name;
        private String email;
        private int participantId;

        public Participant(String name, String email) {
            this.name = name;
            this.email = email;
        }
    }

    // Abstract Question class
    private abstract class Question {
        protected String questionText;
        protected String correctAnswer;
        protected List<String> options;

        public Question(String questionText, String correctAnswer, List<String> options) {
            this.questionText = questionText;
            this.correctAnswer = correctAnswer;
            this.options = options;
        }

        public abstract boolean checkAnswer(String answer);

        @Override
        public String toString() {
            return questionText + "\nOptions: " + String.join(", ", options);
        }
    }

    // MultipleChoiceQuestion class (inherits Question)
    private class MultipleChoiceQuestion extends Question {

        public MultipleChoiceQuestion(String questionText, String correctAnswer, List<String> options) {
            super(questionText, correctAnswer, options);
        }

        @Override
        public boolean checkAnswer(String answer) {
            return correctAnswer.equalsIgnoreCase(answer);
        }
    }

    // TrueFalseQuestion class (inherits Question)
    private class TrueFalseQuestion extends Question {

        public TrueFalseQuestion(String questionText, String correctAnswer) {
            super(questionText, correctAnswer, Arrays.asList("True", "False"));
        }

        @Override
        public boolean checkAnswer(String answer) {
            return correctAnswer.equalsIgnoreCase(answer);
        }
    }

    private void registerParticipant(Participant participant) throws SQLException {
        try {
            // Load the MySQL JDBC driver explicitly (if needed)
            Class.forName("com.mysql.cj.jdbc.Driver");

            boolean emailExists = true;
            while (emailExists) {
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    // Check if the email already exists
                    String checkEmailQuery = "SELECT * FROM Participants WHERE email = ?";
                    PreparedStatement checkEmailStmt = conn.prepareStatement(checkEmailQuery);
                    checkEmailStmt.setString(1, participant.email);
                    ResultSet rs = checkEmailStmt.executeQuery();

                    if (rs.next()) {
                        // Email exists, ask for a new email
                        System.out.println("Email already registered. Please enter a new email.");
                        Scanner scanner = new Scanner(System.in);
                        System.out.print("Enter Participant Email: ");
                        participant.email = scanner.nextLine(); // Take new email from user
                    } else {
                        // No duplicate, break the loop and proceed with registration
                        emailExists = false;
                        String query = "INSERT INTO Participants (name, email) VALUES (?, ?)";
                        PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
                        pstmt.setString(1, participant.name);
                        pstmt.setString(2, participant.email);
                        pstmt.executeUpdate();

                        rs = pstmt.getGeneratedKeys();
                        if (rs.next()) {
                            participant.participantId = rs.getInt(1);
                        }
                        System.out.println("Participant registered with ID: " + participant.participantId);
                    }
                }
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("MySQL JDBC Driver not found.");
        }
    }

    // Quiz class to handle quiz details and questions
    private class Quiz {
        int quizId;
        String title;
        List<Question> questions;

        public Quiz(String title) {
            this.title = title;
            this.questions = new ArrayList<>();
        }

        // Add a question to the quiz
        public void addQuestion(Question question) {
            questions.add(question);
        }
    }

    // Method to create a sample quiz
    private Quiz createSampleQuiz() {
        Quiz quiz = new Quiz("Sample Java Quiz"); // quizId is set to 0 as it will be generated
        List<String> options1 = Arrays.asList("A) byte B) String C) int D) float");
        quiz.addQuestion(new MultipleChoiceQuestion("What is the default value of an int?", "C", options1));

        List<String> options2 = Arrays.asList("True", "False");
        quiz.addQuestion(new TrueFalseQuestion("Java is platform-independent.","True"));

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Insert quiz into Quiz table and retrieve the quiz_id
            String insertQuizQuery = "INSERT INTO Quiz (title) VALUES (?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertQuizQuery, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, quiz.title);
                pstmt.executeUpdate();

                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    quiz.quizId = rs.getInt(1); // Get the generated quiz_id
                } else {
                    throw new SQLException("Failed to retrieve quiz_id.");
                }
            }

            // Insert questions for the quiz
            for (Question question : quiz.questions) {
                String insertQuestionQuery = "INSERT INTO Questions (quiz_id, question_text, correct_answer) VALUES (?, ?, ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(insertQuestionQuery)) {
                    pstmt.setInt(1, quiz.quizId); // Use the generated quiz_id
                    pstmt.setString(2, question.questionText);
                    pstmt.setString(3, question.correctAnswer);
                    pstmt.executeUpdate();
                }
            }

            System.out.println("Quiz created and saved to database with ID: " + quiz.quizId);
        } catch (SQLException e) {
            System.err.println("Error occurred while creating quiz: " + e.getMessage());
            e.printStackTrace();
        }

        return quiz;
    }

    // Method to take the quiz (implemented by QuizOperations interface)
    private void takeQuiz(Participant participant, Quiz quiz) throws SQLException {
        System.out.println("Starting the quiz for " + participant.name);
        Scanner scanner = new Scanner(System.in);
        int score = 0;

        for (Question question : quiz.questions) {
            System.out.println(question);
            System.out.print("Your answer: ");
            String answer = scanner.nextLine();

            if (question.checkAnswer(answer)) {
                score++;
            }
        }
        saveResult(participant, quiz.quizId, score);
        System.out.println("Quiz finished! Your score is: " + score);
    }

    // Method to view the participant's score
    private void viewScore(Participant participant) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT q.title, r.score FROM QuizResults r INNER JOIN Quiz q ON r.quiz_id = q.quiz_id WHERE r.participant_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, participant.participantId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String quizTitle = rs.getString("title");
                int score = rs.getInt("score");
                System.out.println("Quiz: " + quizTitle + " | Score: " + score);
            }
        }
    }

    // Method to save quiz results to the database
    private void saveResult(Participant participant, int quizId, int score) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO QuizResults (participant_id, quiz_id, score) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, participant.participantId);
            pstmt.setInt(2, quizId);
            pstmt.setInt(3, score);
            pstmt.executeUpdate();
            System.out.println("Score saved to database.");
        }
    }
}
