CREATE DATABASE quizApplication;
USE quizApplication;

-- Table: Participants
CREATE TABLE Participants (
    participant_id INT AUTO_INCREMENT PRIMARY KEY,  -- Auto-increment added
    name VARCHAR(100),
    email VARCHAR(100)
);
select*from Participants;

-- Table: Quiz
CREATE TABLE Quiz (
    quiz_id INT AUTO_INCREMENT PRIMARY KEY,  -- Auto-increment added
    title VARCHAR(100),
    description TEXT
);
select*from Quiz;
-- Table: Questions
CREATE TABLE Questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,  -- Auto-increment added
    quiz_id INT,
    question_text TEXT,
    question_type VARCHAR(20),
    correct_answer VARCHAR(255),
    FOREIGN KEY (quiz_id) REFERENCES Quiz(quiz_id)
);
select*from Questions;
-- Table: Options
CREATE TABLE Options (
    option_id INT AUTO_INCREMENT PRIMARY KEY,  -- Auto-increment added
    question_id INT,
    option_text VARCHAR(255),
    is_correct BOOLEAN,
    FOREIGN KEY (question_id) REFERENCES Questions(question_id)
);
select*from Options;
-- Table: QuizResults
CREATE TABLE QuizResults (
    result_id INT AUTO_INCREMENT PRIMARY KEY,  -- Auto-increment added
    participant_id INT,
    quiz_id INT,
    score INT,
    date_taken TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Default current timestamp added
    FOREIGN KEY (participant_id) REFERENCES Participants(participant_id),
    FOREIGN KEY (quiz_id) REFERENCES Quiz(quiz_id)
);
select*from QuizResults;