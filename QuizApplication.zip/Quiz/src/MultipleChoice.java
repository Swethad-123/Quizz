public class MultipleChoice extends Question {
    private String[] options;

    public MultipleChoice(int questionId, String questionText, String correctAnswer, String[] options) {
        super(questionId, questionText, correctAnswer);
        this.options = options;
    }

    @Override
    public boolean checkAnswer(String answer) {
        return answer.equalsIgnoreCase(correctAnswer);
    }

    public String[] getOptions() {
        return options;
    }

    public void setOptions(String[] options) {
        this.options = options;
    }

    @Override
    public String toString() {
        return super.toString() + ", Options=" + String.join(", ", options);
    }
}