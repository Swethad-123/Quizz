import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

// Update the QuizManager to save results to the database
public class QuizManager implements QuizOperations, ScoreOperations {
    private int score;
    private Participant participant;
    private Quiz quiz;
    private Question[] questions;

    public QuizManager(Participant participant, Quiz quiz, Question[] questions) {
        this.participant = participant;
        this.quiz = quiz;
        this.questions = questions;
        this.score = 0;
    }

    // Implement takeQuiz() from QuizOperations
    @Override
    public void takeQuiz() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Starting Quiz: " + quiz.getTitle());
        System.out.println("Description: " + quiz.getDescription());

        for (Question question : questions) {
            System.out.println(question.getQuestionText());
            if (question instanceof MultipleChoice) {
                MultipleChoice mcQuestion = (MultipleChoice) question;
                for (String option : mcQuestion.getOptions()) {
                    System.out.println(option);
                }
            }

            System.out.print("Enter your answer: ");
            String answer = scanner.nextLine();

            // Check if the answer is correct
            if (question.checkAnswer(answer)) {
                score++;
            }
        }
    }

    // Implement viewScore() from QuizOperations
    @Override
    public void viewScore() {
        System.out.println("Your score: " + score + " out of " + questions.length);
    }

    // Implement calculateScore() from ScoreOperations
    @Override
    public void calculateScore() {
        // Already calculated during takeQuiz(), so no further action needed here.
    }

    // Implement showScore() from ScoreOperations
    @Override
    public void showScore() {
        System.out.println("Your final score: " + score);
    }

    // Save participant data to the database
    public void saveParticipantData() {
        try (Connection conn = DBConnection.getConnection()) {
            String insertParticipantSQL = "INSERT INTO Participants (name, email) VALUES (?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertParticipantSQL)) {
                pstmt.setString(1, participant.getName());
                pstmt.setString(2, participant.getEmail());
                pstmt.executeUpdate();
                System.out.println("Participant data saved to the database.");
            }
        } catch (SQLException e) {
            System.out.println("Error saving participant data: " + e.getMessage());
        }
    }

    // Save quiz result to the database
    public void saveQuizResult() {
        try (Connection conn = DBConnection.getConnection()) {
            String insertResultSQL = "INSERT INTO QuizResults (participant_id, quiz_id, score, date_taken) " +
                    "VALUES ((SELECT participant_id FROM Participants WHERE email = ?), ?, ?, NOW())";
            try (PreparedStatement pstmt = conn.prepareStatement(insertResultSQL)) {
                pstmt.setString(1, participant.getEmail());  // Use participant's email to retrieve ID
                pstmt.setInt(2, quiz.getQuizId());
                pstmt.setInt(3, score);
                pstmt.executeUpdate();
                System.out.println("Quiz result saved to the database.");
            }
        } catch (SQLException e) {
            System.out.println("Error saving quiz result: " + e.getMessage());
        }
    }
}
