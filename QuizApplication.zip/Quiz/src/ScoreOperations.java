// Interface for Score operations
public interface ScoreOperations {
    void calculateScore(); // Method to calculate the score
    void showScore();      // Method to display the score
}
