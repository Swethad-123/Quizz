public class TrueFalse extends Question {
    public TrueFalse(int questionId, String questionText, String correctAnswer) {
        super(questionId, questionText, correctAnswer);
    }

    @Override
    public boolean checkAnswer(String answer) {
        return answer.equalsIgnoreCase(correctAnswer);
    }
}