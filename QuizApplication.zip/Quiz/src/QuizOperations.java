// Interface for Quiz operations
public interface QuizOperations {
    void takeQuiz();  // Method to start the quiz
    void viewScore(); // Method to view score
}
